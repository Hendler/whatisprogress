---
title: Haikuduo – two people writing haiku on Twitter
author: hendler
type: page
date: 2009-02-21T16:22:34+00:00

---
On Twitter, write one line of haiku, and ask a friend for the next, then you complete. Here is the work of a friend and I over a couple of months.

  1. This rose bud opens, bright sun heating soft petals, cold dew yawns awake.
  2. Compressed, near success, unravel life&#8217;s deep secret, life waits in pea pod
  3. Feel that small stillness, pool of water under stone, stirs ensnared thoughts free
  4. Streaks of light below, an instant seems infinite, floating on water
  5. Glances veiled in grime, salamander wades in mud, strangled by envy
  6. Cardinal plays note, Steering the sightless from far, Flies through canopy
  7. Crowding the footpath, Clumps of lush sod hide edges, Beauty neglected
  8. Invisible wind, Howling with abandoned pain, While touching no one (or &#8220;The devastation&#8221; for Darfur)
  9. Black squirrel scurries, claws scrape the earth and tail up, Curious friendship
 10. Tomato pollen, Watery eyes scratchy throat, smell of baking dirt
 11. Old oak stoops wisdom, New acorns spread far and wide, A sanctuary.
 12. The strongest pigeon ,On the wing searching the earth, Coos roof top dancing
 13. Pause, a startled stare, Rigid whiskers crown the nose, Stillness sparks action
 14. Rolling, calm inside, Green hills nestle roaring streams, pebbles filtering
 15. Countless shades of green, cloud forests scrape the white sky, Fragile artistry
 16. Huddled kin find shade, Existential radiance, Camaraderie
 17. Leaf flutters unsure, brilliant red a parting gift, cushions toddler&#8217;s fall
 18. Rain during the night, Comfort, smell of dry earth quenched , Ridges in the mud.
 19. Stories enrapture, Making sense out of chaos, Soothing, drift to dreams
 20. One arm above head, The dancer spins on her toes, Flowing with sea breeze
 21. Respite from the heat, Desert life rests until night, Cerulean sky
 22. Strawberry rhubarb, Wilderness garden medley, Irresistible
 23. Flying yet no wings, Dandelion light curtain, Hopes drift from grass bed
 24. Walden Pond Sunday; Water, sand, stories they tell; As a train goes by
 25. It&#8217;s imperfection, Near a twilight silhouette, Radiance beckons
 26. Still, cricket chirps, Sultry night awaits downpour, Neither breeze nor star
 27. Wind steals blank pages, strewing sharp edges of white, Unfinished story
 28. One thousand footsteps, Coiled body clings to leaf, Silk yarn to cocoon
 29. Song absent of tune, Vacuous expanse of light, Words of compassion
 30. Ripe lychee perfume, Marketplace bewilderment, Colors, commotion
 31. Ladybird takes wing, Home, a bespeckled vineyard, Few grapes, joy of wine
 32. Summer yesterday, Marigolds, blue jays, ice cream, Harvest done and shared
 33. Fall leaves work is art, Wilting blisters pop to smoke, Forest in ashes
 34. Dockside wood barrels, Gulls cackle from perch atop, Waves stir beneath fog
 35. Harvest moon&#8217;s bright glow, Diamond frost covers grass, Sunrise paints the sky