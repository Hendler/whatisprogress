---
title: About
author: hendler
type: page
date: 2013-02-21T07:05:26+00:00

---
Increase the quality and usability of information to solve complex sociological problems.

  * <a style="line-height:1.6;" title="View public profile" href="http://www.linkedin.com/in/jonathanhendler/" name="webProfileURL">www.linkedin.com/in/jonathanhendler/</a>
  * <a style="line-height:1.6;" href="https://twitter.com/hendler">twitter.com/hendler</a>

About HAI

**Human Assisted Intelligence**. HAI will help computers learn about people.