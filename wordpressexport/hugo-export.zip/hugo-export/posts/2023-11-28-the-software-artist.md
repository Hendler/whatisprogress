---
title: THE SOFTWARE ARTIST
author: hendler
type: post
date: 2023-11-28T13:56:39+00:00
url: /?p=846
wordads_ufa:
  - u:wpcom-ufa-v4:1701184447
wpcom_is_first_post:
  - 1
timeline_notification:
  - 1701179802
categories:
  - Uncategorized

---
<img decoding="async" src="https://cdn.discordapp.com/attachments/1086058134612750478/1179055700081651812/hai.ai_a_software_artist_portrait_by_anne_liebovitz_a1e06c68-957e-4173-9bb9-b1f7289d39d6.png" />

I am not a computer scientist. But I am in love with the edge of what is knowable and possible.

I am not an engineer. But I can build intricate things, trace small details, and I know the materials.

I am not a software architect. But I think in the systems that move information through dimensions.

I am not a manager. But I love builders because I cherish the pain and joy of fitting reality to us and with each other.

I am not a designer. But I understand designs as a process to consciousness.

I am not a data scientist. But I desire data to surprise me with the truth.

I do not build money generation engines. But what I&#8217;ve built has generated outsized value.

I am painting pictures with software. 

There are many great artists. I am neither unique nor better. But this is my heart. So I give myself license.

Today, software is the most powerful medium I can wield. But software is changing. And so will I.

<figure class="wp-block-image size-large">

[<img loading="lazy" decoding="async" width="2048" height="2048" src="http://wp.docker.localhost:8000/wp-content/uploads/2023/11/image-1.png?w=1024" alt="" class="wp-image-855" srcset="http://wp.docker.localhost:8000/wp-content/uploads/2023/11/image-1.png 2048w, http://wp.docker.localhost:8000/wp-content/uploads/2023/11/image-1-300x300.png 300w, http://wp.docker.localhost:8000/wp-content/uploads/2023/11/image-1-1024x1024.png 1024w, http://wp.docker.localhost:8000/wp-content/uploads/2023/11/image-1-150x150.png 150w, http://wp.docker.localhost:8000/wp-content/uploads/2023/11/image-1-768x768.png 768w, http://wp.docker.localhost:8000/wp-content/uploads/2023/11/image-1-1536x1536.png 1536w" sizes="auto, (max-width: 2048px) 100vw, 2048px" />][1]</figure>

 [1]: http://wp.docker.localhost:8000/wp-content/uploads/2023/11/image-1.png