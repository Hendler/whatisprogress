---
title: Earning leadership in parenthood and business.
author: hendler
type: post
date: 2011-11-29T04:41:00+00:00
excerpt: "As a leader, control leaves your hands in one of two ways: by consent, or not by consent. Either way it happens. Choose consent. Maybe this is the opposite of the Steve Jobs. I really don't know, but feels like Jobs had a great sense of timing, ho..."
url: /?p=13
categories:
  - Uncategorized

---
**As a leader, control leaves your hands in one of two ways: by consent, or not by consent. Either way it happens. Choose consent.**

Maybe this is the opposite of the Steve Jobs. I really don&#8217;t know, but feels like Jobs had a great sense of timing, how far he could fight for what he believed, and when to &#8220;give in&#8221;.

Perhaps there is no way to stop people from [putting beans up their nose][1]. Having insight ignored is painful if you care at all about what you are doing.  If the fight is too extended, no matter if right or wrong, you end up appearing arrogant or stubborn, but if you are right it doesn&#8217;t matter. And if a company needs focus and either way is right, it doesn&#8217;t matter which is chosen, only that something is chosen and committed to.

I read Herman Hesse&#8217;s [&#8220;Journey to the East&#8221;][2] twenty years ago. Summary: leadership is service. As a new parent, I think this is especially true.

 [1]: http://www.uie.com/brainsparks/2011/07/08/beans-and-noses/
 [2]: http://en.wikipedia.org/wiki/Journey_to_the_East "Wikipedia Entry"