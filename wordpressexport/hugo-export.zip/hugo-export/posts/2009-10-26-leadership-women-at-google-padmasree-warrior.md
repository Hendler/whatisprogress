---
title: 'Leadership: Women at Google – Padmasree Warrior'
author: hendler
type: post
date: 2009-10-26T16:56:11+00:00
url: /?p=39
categories:
  - Uncategorized
tags:
  - cisco
  - internet
  - technology

---
<span style="line-height:1.6;">Cisco can compete in many markets (the talk mentions 40) because it understands not only technology, but the context and culture which creates the demand for technology.</span>

[youtube=http://www.youtube.com/watch?v=gWL841Mqsus&w=560&h=340]