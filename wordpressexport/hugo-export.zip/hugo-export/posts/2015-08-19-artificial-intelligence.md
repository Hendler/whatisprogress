---
title: Artificial Intelligence
author: hendler
type: post
date: 2015-08-19T05:52:16+00:00
url: /?p=84
publicize_twitter_user:
  - hendler
publicize_linkedin_url:
  - 'https://www.linkedin.com/updates?discuss=&scope=6826798&stype=M&topic=6039644833079898112&type=U&a=so3C'
categories:
  - Uncategorized

---
A variety of slightly curated youtube videos on the topic of AI.

## Ethics, Thinking

[youtube https://www.youtube.com/watch?v=u0R6pV_aeLc&w=560&h=315]

[youtube https://www.youtube.com/watch?v=pywF6ZzsghI]

[youtube https://www.youtube.com/watch?v=GYQrNfSmQ0M&w=560&h=315]

[youtube https://www.youtube.com/watch?v=5rNKtramE-I&w=560&h=315]

## Integration with Human Work

[youtube https://www.youtube.com/watch?v=-Ht4qiDRZE8&w=560&h=315]

[youtube https://www.youtube.com/watch?v=ltelQ3iKybU&w=560&h=315]

[youtube https://www.youtube.com/watch?v=dpoVh9xwdD4&w=560&h=315]

## Deep Learning

[youtube https://www.youtube.com/watch?v=kxp7eWZa-2M&w=560&h=315]

[youtube https://www.youtube.com/watch?v=wTp3P2UnTfQ&w=560&h=315]

[youtube https://www.youtube.com/watch?v=vkfXBGnDplQ&w=560&h=315]

## Future

[youtube https://www.youtube.com/watch?v=PL0Xq0FFQZ4&w=560&h=315]