---
title: Thank you XEROX (for not Patenting the GUI)
author: hendler
type: post
date: 2010-04-05T15:22:38+00:00
excerpt: "Dear XEROX (PARC), Thank you for not patenting the Graphic User Interface. Conventional wisdom has been that XEROX missed out on a huge opportunity - and maybe that's true. However, maybe Microsoft and Apple (and Linux for that matter) would have ..."
url: /?p=9
categories:
  - Uncategorized

---
Dear XEROX (PARC), 

Thank you for not patenting the Graphic User Interface. </p> 

Conventional wisdom has been that XEROX missed out on a huge opportunity &#8211; and maybe that&#8217;s true. However, maybe Microsoft and Apple (and Linux for that matter) would have never been such great successes. Maybe we would all have had to wait for the Newton or the IPad before the innovation could have been surpassed.  
Windows 7 was not my idea.</p>